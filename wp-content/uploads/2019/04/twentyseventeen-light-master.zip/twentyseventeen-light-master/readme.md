# Twenty Seventeen Light

WordPress Twenty Seventeen Child Theme.

### Changes:
  - Disabled all .js files on frontend.
  - Disabled all .css files on frontend except base theme style.css file.
  - Disabled everything about emoji's.
  - Minified style.css file.

### Performance
Approximate difference

| | Twenty Seventeen | Twenty Seventeen Light |
| ------ | ------ | ------ |
| Requests | 16 | 2 |
| Page size | 147 KB | 28 KB |
| Load time | 400 ms | 70 ms |
